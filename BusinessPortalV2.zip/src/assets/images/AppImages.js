import onecall from "./onecall.png"
const AppImages = {
  onecallLogo: onecall 
}

export default AppImages