import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";
import DashboardScreen from "../Dashboard/DashboardScreen.jsx";

function AnalyticsScreen() {
  return (  
    <DashboardTemplate pageTitle={"Analytics"}>

    </DashboardTemplate>
  );
}

export default AnalyticsScreen;