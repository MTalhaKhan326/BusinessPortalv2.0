import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";

function MessagesScreen() {
  return (  
    <DashboardTemplate pageTitle={"Messages"}>

    </DashboardTemplate>
  );
}

export default MessagesScreen;