import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";

function SettingsScreen() {
  return (  
    <DashboardTemplate pageTitle={"Settings"}>

    </DashboardTemplate>
  );
}

export default SettingsScreen;