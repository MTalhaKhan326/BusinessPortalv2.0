import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";

function HelpScreen() {
  return (  
    <DashboardTemplate pageTitle={"Help"}>

    </DashboardTemplate>
  );
}

export default HelpScreen;