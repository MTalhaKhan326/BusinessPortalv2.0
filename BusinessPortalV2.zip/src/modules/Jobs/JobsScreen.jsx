import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";

function JobsScreen() {
  return (  
    <DashboardTemplate pageTitle={"Jobs"}>

    </DashboardTemplate>
  );
}

export default JobsScreen;