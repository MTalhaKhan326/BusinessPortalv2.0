import React from 'react'
import ListingTemplate from '../../ListingTemplate'

const Dashboard = () => {
  return (
    <ListingTemplate>
      <div>Dashboard</div>
    </ListingTemplate>
  );
}

export default Dashboard