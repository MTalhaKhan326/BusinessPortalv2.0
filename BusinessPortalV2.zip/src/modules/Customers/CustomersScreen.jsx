import DashboardTemplate from "../../components/Templates/DashboardTemplate.jsx";

function CustomersScreen() {
  return (  
    <DashboardTemplate pageTitle={"Customers"}>

    </DashboardTemplate>
  );
}

export default CustomersScreen;